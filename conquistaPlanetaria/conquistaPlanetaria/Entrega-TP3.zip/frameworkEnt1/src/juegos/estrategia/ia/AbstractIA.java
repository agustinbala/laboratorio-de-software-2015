package juegos.estrategia.ia;

import juegos.estrategia.PlanetWars;

public interface AbstractIA {
	void makeAMove(PlanetWars pw);
}
